# logging-util

A reusable Python logging utility.

## Installation

```bash
pip install logging-util
